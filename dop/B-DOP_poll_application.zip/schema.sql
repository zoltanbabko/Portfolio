CREATE TABLE IF NOT EXISTS votes
(
  id text PRIMARY KEY,
  vote text NOT NULL
);
